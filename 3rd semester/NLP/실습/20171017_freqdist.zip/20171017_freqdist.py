import nltk
from nltk.corpus import brown
news_text = brown.words(categories='news')
fdist = nltk.FreqDist(w.lower() for w in news_text)
fdist.most_common(50) # 최빈 50개를 반환하는 메소드

# stopword 제거 조건 추가하기

try:
    from nltk.corpus import stopwords
except:
    nltk.download('stopwords')
    from nltk.corpus import stopwords

stopwords.words('english')

sent = 'There is also a corpus of stopwords, that is, high-frequency words like the, to and also that we sometimes want to filter out of a document before further processing.'
sent = sent.lower().split()
print('stopword 제거 전')
print(list(nltk.bigrams(sent)))
sent = [item for item in sent if item not in stopwords.words('english')]
print('stopword 제거 후')
print(list(nltk.bigrams(sent)))

# http://nltk.org/book/ch02
# 17. ◑ Write a function that finds the 50 most frequently occurring words of a text that are not stopwords.
# 18. ◑ Write a program to print the 50 most frequent bigrams (pairs of adjacent words) of a text, omitting bigrams that contain stopwords.



