def myngrams(sent, n, boundary = True):
    if boundary:
        sent = (n-1) * ['<s>'] + sent + (n-1) * ['</s>']
    
    ngram_list = [sent[i:i+n] for i in range(len(sent)-n+1)]
    
    return ngram_list



sent1 = 'Twinkle twinkle little star how i wonder what you are'
print(myngrams(sent1.split(), 2, True))
print(myngrams(sent1.split(), 2, False))
print(myngrams(sent1.split(), 3, True))
print(myngrams(sent1.split(), 3, False))

















